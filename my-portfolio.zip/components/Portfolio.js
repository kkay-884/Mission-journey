import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";

const navItems = ["Home", "About", "Services", "Contact"];

export default function Portfolio() {
  const router = useRouter();
  const [active, setActive] = useState(router.pathname);

  const renderContent = () => {
    switch (active) {
      case "/about":
        return (
          <section className="text-center">
            <h2 className="text-4xl font-bold mb-4 text-gray-800">About Me</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              I’m a full-stack developer with experience in React, Node.js, and building scalable web apps. I love solving problems and learning new technologies.
            </p>
          </section>
        );
      case "/services":
        return (
          <section className="text-center">
            <h2 className="text-4xl font-bold mb-4 text-gray-800">Services</h2>
            <ul className="text-lg text-gray-600 max-w-2xl mx-auto space-y-4">
              <li>- Web Development (React, Next.js)</li>
              <li>- UI/UX Design with Tailwind CSS</li>
              <li>- Backend APIs with Node.js/Express</li>
              <li>- Full-stack App Deployment (Vercel, Railway)</li>
            </ul>
          </section>
        );
      case "/contact":
        return (
          <section className="text-center">
            <h2 className="text-4xl font-bold mb-4 text-gray-800">Contact Me</h2>
            <p className="text-lg text-gray-600">Feel free to reach out via email at <a href="mailto:you@example.com" className="text-indigo-600 underline">you@example.com</a>.</p>
          </section>
        );
      default:
        return (
          <section className="text-center">
            <h2 className="text-4xl font-bold mb-4 text-gray-800">Welcome to My Portfolio</h2>
            <p className="text-lg text-gray-600">
              I'm a passionate developer who builds beautiful and responsive web experiences.
            </p>
          </section>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-pink-100 to-yellow-100">
      <header className="p-6 bg-white shadow-md sticky top-0 z-50">
        <nav className="flex justify-between items-center max-w-5xl mx-auto">
          <h1 className="text-2xl font-bold text-indigo-600">My Portfolio</h1>
          <ul className="flex space-x-6 text-gray-700">
            {navItems.map((item) => (
              <li key={item}>
                <Link href={`/${item.toLowerCase()}`}>
                  <span
                    onClick={() => setActive(`/${item.toLowerCase()}`)}
                    className={\`cursor-pointer hover:text-indigo-600 transition \${active === \`/${item.toLowerCase()}\` ? "text-indigo-600 font-semibold" : ""}\`}
                  >
                    {item}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </header>

      <main className="max-w-4xl mx-auto py-12 px-4">
        {renderContent()}
      </main>

      <footer className="text-center py-6 text-gray-500 border-t">
        © {new Date().getFullYear()} My Portfolio. All rights reserved.
      </footer>
    </div>
  );
}
