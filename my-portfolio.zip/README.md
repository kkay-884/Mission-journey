# My Portfolio

This is a clean, minimal, and colorful personal portfolio site built with Next.js and Tailwind CSS.

## Features

- Responsive Design
- Pages: Home, About, Services, Contact
- Easy deployment with Vercel

## Getting Started

```bash
npm install
npm run dev
```

## Deploy

- Push to GitHub
- Connect repository on [Vercel](https://vercel.com)
- Done!
